<?php

namespace ContainerUDQdrzp;

include_once \dirname(__DIR__, 4).'/vendor/doctrine/persistence/lib/Doctrine/Persistence/ObjectManager.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).'/vendor/doctrine/orm/lib/Doctrine/ORM/EntityManager.php';
class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    private $valueHolder5d9ae = null;
    private $initializer2ddcb = null;
    private static $publicPropertiesd31e2 = [
        
    ];
    public function getConnection()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getConnection', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getConnection();
    }
    public function getMetadataFactory()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getMetadataFactory', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getMetadataFactory();
    }
    public function getExpressionBuilder()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getExpressionBuilder', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getExpressionBuilder();
    }
    public function beginTransaction()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'beginTransaction', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->beginTransaction();
    }
    public function getCache()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getCache', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getCache();
    }
    public function transactional($func)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'transactional', array('func' => $func), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->transactional($func);
    }
    public function commit()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'commit', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->commit();
    }
    public function rollback()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'rollback', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->rollback();
    }
    public function getClassMetadata($className)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getClassMetadata', array('className' => $className), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getClassMetadata($className);
    }
    public function createQuery($dql = '')
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'createQuery', array('dql' => $dql), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->createQuery($dql);
    }
    public function createNamedQuery($name)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'createNamedQuery', array('name' => $name), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->createNamedQuery($name);
    }
    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->createNativeQuery($sql, $rsm);
    }
    public function createNamedNativeQuery($name)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->createNamedNativeQuery($name);
    }
    public function createQueryBuilder()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'createQueryBuilder', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->createQueryBuilder();
    }
    public function flush($entity = null)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'flush', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->flush($entity);
    }
    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->find($className, $id, $lockMode, $lockVersion);
    }
    public function getReference($entityName, $id)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getReference($entityName, $id);
    }
    public function getPartialReference($entityName, $identifier)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getPartialReference($entityName, $identifier);
    }
    public function clear($entityName = null)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'clear', array('entityName' => $entityName), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->clear($entityName);
    }
    public function close()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'close', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->close();
    }
    public function persist($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'persist', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->persist($entity);
    }
    public function remove($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'remove', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->remove($entity);
    }
    public function refresh($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'refresh', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->refresh($entity);
    }
    public function detach($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'detach', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->detach($entity);
    }
    public function merge($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'merge', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->merge($entity);
    }
    public function copy($entity, $deep = false)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->copy($entity, $deep);
    }
    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->lock($entity, $lockMode, $lockVersion);
    }
    public function getRepository($entityName)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getRepository', array('entityName' => $entityName), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getRepository($entityName);
    }
    public function contains($entity)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'contains', array('entity' => $entity), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->contains($entity);
    }
    public function getEventManager()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getEventManager', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getEventManager();
    }
    public function getConfiguration()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getConfiguration', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getConfiguration();
    }
    public function isOpen()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'isOpen', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->isOpen();
    }
    public function getUnitOfWork()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getUnitOfWork', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getUnitOfWork();
    }
    public function getHydrator($hydrationMode)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getHydrator($hydrationMode);
    }
    public function newHydrator($hydrationMode)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->newHydrator($hydrationMode);
    }
    public function getProxyFactory()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getProxyFactory', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getProxyFactory();
    }
    public function initializeObject($obj)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'initializeObject', array('obj' => $obj), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->initializeObject($obj);
    }
    public function getFilters()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'getFilters', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->getFilters();
    }
    public function isFiltersStateClean()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'isFiltersStateClean', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->isFiltersStateClean();
    }
    public function hasFilters()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'hasFilters', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return $this->valueHolder5d9ae->hasFilters();
    }
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;
        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);
        $instance->initializer2ddcb = $initializer;
        return $instance;
    }
    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;
        if (! $this->valueHolder5d9ae) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder5d9ae = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
        }
        $this->valueHolder5d9ae->__construct($conn, $config, $eventManager);
    }
    public function & __get($name)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__get', ['name' => $name], $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        if (isset(self::$publicPropertiesd31e2[$name])) {
            return $this->valueHolder5d9ae->$name;
        }
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d9ae;
            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolder5d9ae;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __set($name, $value)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__set', array('name' => $name, 'value' => $value), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d9ae;
            $targetObject->$name = $value;
            return $targetObject->$name;
        }
        $targetObject = $this->valueHolder5d9ae;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();
        return $returnValue;
    }
    public function __isset($name)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__isset', array('name' => $name), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d9ae;
            return isset($targetObject->$name);
        }
        $targetObject = $this->valueHolder5d9ae;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();
        return $returnValue;
    }
    public function __unset($name)
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__unset', array('name' => $name), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');
        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder5d9ae;
            unset($targetObject->$name);
            return;
        }
        $targetObject = $this->valueHolder5d9ae;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);
            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }
    public function __clone()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__clone', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        $this->valueHolder5d9ae = clone $this->valueHolder5d9ae;
    }
    public function __sleep()
    {
        $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, '__sleep', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
        return array('valueHolder5d9ae');
    }
    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }
    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializer2ddcb = $initializer;
    }
    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializer2ddcb;
    }
    public function initializeProxy() : bool
    {
        return $this->initializer2ddcb && ($this->initializer2ddcb->__invoke($valueHolder5d9ae, $this, 'initializeProxy', array(), $this->initializer2ddcb) || 1) && $this->valueHolder5d9ae = $valueHolder5d9ae;
    }
    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder5d9ae;
    }
    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder5d9ae;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
